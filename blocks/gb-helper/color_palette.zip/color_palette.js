
const color_palette_list = [
    { name: "HotPink ", color: "#FF69B4" },
    { name: "MediumOrchid ", color: "#BA55D3" },
    { name: "RebeccaPurple ", color: "#663399" },
    { name: "DarkSalmon ", color: "	#E9967A" },
    { name: "FireBrick ", color: "#B22222" },
    { name: "DarkOrange ", color: "#FF8C00" },
    { name: "Tomato ", color: "	#FF6347" },
    { name: "Moccasin ", color: "#FFE4B5" },
    { name: "DarkKhaki ", color: "#BDB76B" },
    { name: "Lime ", color: "#00FF00" },
    { name: "red", color: "	#FF0000" },
    { name: "green", color: "#008000" },
    { name: "blue", color: "#0000FF" },
    { name: "yellow", color: "#FFFF00" },
    { name: "pink", color: "#FFC0CB" },
    { name: "white", color: "#FFFFFF" },
    { name: "gray", color: "#DCDCDC" },
    { name: "black", color: "#000000" },

]
export default color_palette_list;